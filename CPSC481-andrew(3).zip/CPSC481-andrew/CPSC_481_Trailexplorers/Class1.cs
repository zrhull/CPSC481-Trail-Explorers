﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPSC_481_Trailexplorers
{
    public class SliderControl2
    {
        public string SliderName2 { get; set; }
        public int SliderId2 { get; set; }
    }



}

