﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPSC_481_Trailexplorers
{
    public class Difficulty
    {
        public string DifficultyName { get; set; }
        public int DifficultyId { get; set; }
   
    }
}
