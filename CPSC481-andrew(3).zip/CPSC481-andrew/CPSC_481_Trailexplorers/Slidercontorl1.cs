﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPSC_481_Trailexplorers
{
    public class Slidercontrol1
    {
        public int SliderName1 { get; set; }
        public int SliderId1 { get; set; }
    }
}