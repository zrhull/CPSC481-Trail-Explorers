﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPSC_481_Trailexplorers
{
    public class SliderControl3
    {
        public string SliderName3 { get; set; }
        public int SliderId3 { get; set; }
    }



}