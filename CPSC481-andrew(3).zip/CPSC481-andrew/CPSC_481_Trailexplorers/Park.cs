﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CPSC_481_Trailexplorers
{
    public class Park
    {
        public string ParkName { get; set; }
        public int ParkId { get; set; }

        public int diff { get; set; }
    }
}
